# -*- mode: sh; coding: utf-8 -*-

export PYTHONPATH=$PYTHONPATH:$(pwd)/src
