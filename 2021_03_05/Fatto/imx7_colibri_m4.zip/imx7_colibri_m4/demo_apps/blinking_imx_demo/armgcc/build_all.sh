#!/bin/sh
cd debug/
./build_debug.sh
cd ..
cd release/
./build_release.sh
cd ..
