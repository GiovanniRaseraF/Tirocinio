examples/imx7_colibri_m4/demo_apps/rpmsg/pingpong_bm/iar/

This folder contained NXP files. For license reasons we are not allowed to redistribute them.
Please refer to the original NXP sources to acquire the IAR project files:

- projectname.ewd
- projectname.ewp
- projectname.eww



